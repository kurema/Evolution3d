#pragma once


namespace PhysX
{
	public ref class VehicleUtil sealed
	{
	public:
		static bool IsInAir(Query);
	};
};