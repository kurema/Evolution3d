#include "StdAfx.h"
#include "FixedSizeLookupTable.h"

//void FixedSizeLookupTable::AddPair(float x, float y)
//{
//	_table->addPair(x, y);
//}
//
//float FixedSizeLookupTable::GetYValue(float x)
//{
//	_table->getYVal(x);
//}
//
//int FixedSizeLookupTable::NumberOfPairs::get()
//{
//	return _table->getNumOfPairs();
//}
