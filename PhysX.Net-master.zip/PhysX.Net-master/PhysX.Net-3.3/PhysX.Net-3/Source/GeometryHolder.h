#pragma once

//#include "Geometry.h"

//namespace PhysX
//{
//	public ref class GeometryHolder
//	{
//	internal:
//		static Geometry^ GetGeometryFromUnmanaged(PxGeometryHolder* gh);
//	};
//}