#pragma once

//#include <PxObserver.h> 
//
//namespace PhysX
//{
//	public ref class Observer
//	{
//		private:
//			PxObserver* _observer;
//
//		internal:
//			Observer(PxObserver* observer);
//		public:
//			~Observer();
//		protected:
//			!Observer();
//		
//		internal:
//			property PxObserver* UnmanagedPointer
//			{
//				PxObserver* get();
//			}
//	};
//};