#include "StdAfx.h"
#include "ConstraintConnector.h"

void ConstraintConnector::PrepareData()
{
	throw gcnew NotImplementedException();
}

bool ConstraintConnector::UpdatePvdProperties()
{
	throw gcnew NotImplementedException();
}

void ConstraintConnector::OnConstraintRelease()
{
	throw gcnew NotImplementedException();
}

void ConstraintConnector::OnComShift(int actor)
{
	throw gcnew NotImplementedException();
}