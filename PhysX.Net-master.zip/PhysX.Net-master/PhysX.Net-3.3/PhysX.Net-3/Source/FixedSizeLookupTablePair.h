#pragma once

namespace PhysX
{
	[StructLayout(LayoutKind::Explicit)]
	public value class FixedSizeLookupTablePair
	{
		public:
			property float X;
			property float Y;
	};
};