#include "StdAfx.h"
#include "ConstraintDesc.h"

ConstraintDesc::ConstraintDesc()
{
	
}