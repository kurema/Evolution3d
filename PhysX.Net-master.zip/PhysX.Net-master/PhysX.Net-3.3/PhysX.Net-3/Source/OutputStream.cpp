#include "StdAfx.h"
#include "OutputStream.h"

OutputStream::OutputStream()
{

}