#pragma once


namespace PhysX
{
	public interface class IPhysXEntity
	{
		
	};
}