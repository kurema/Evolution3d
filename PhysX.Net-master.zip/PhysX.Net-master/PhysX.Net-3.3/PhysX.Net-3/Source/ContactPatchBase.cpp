#include "StdAfx.h"
#include "ContactPatchBase.h"

