#include "StdAfx.h"
#include "DebugLine.h"

DebugLine::DebugLine(Vector3 point0, int color0, Vector3 point1, int color1)
{
	Point0 = point0;
	Color0 = color0;

	Point1 = point1;
	Color1 = color1;
}