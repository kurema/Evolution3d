#pragma once

namespace PhysX
{
	public ref class ConstraintShaderTable
	{

	};
}