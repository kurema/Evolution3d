#include "StdAfx.h"
#include "ObservableInstance.h"

//ObservableInstance::ObservableInstance(PxObservable* observable)
//{
//	_observable = observable;
//}
//
//PxObservable* ObservableInstance::UnmanagedPointer::get()
//{
//	return _observable;
//}