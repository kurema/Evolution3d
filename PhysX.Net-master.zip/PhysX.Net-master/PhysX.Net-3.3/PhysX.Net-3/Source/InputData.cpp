#include "StdAfx.h"
#include "InputData.h"

InputData::InputData()
{

}