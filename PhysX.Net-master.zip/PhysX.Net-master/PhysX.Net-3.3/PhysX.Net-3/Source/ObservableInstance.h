#pragma once

//#include "ObservableEnum.h"
//#include "IObserver.h"
//
//namespace PhysX
//{
//	public ref class ObservableInstance
//	{
//		private:
//			PxObservable* _observable;
//
//		public:
//			ObservableInstance(PxObservable* observable);
//
//		internal:
//			property PxObservable* UnmanagedPointer
//			{
//				PxObservable* get();
//			}
//	};
//};