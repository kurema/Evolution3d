#pragma once


namespace PhysX
{
	/// <summary>
	/// 
	/// </summary>
	public ref class VehicleGraph
	{
		internal:
			

		public:
			
	};
};