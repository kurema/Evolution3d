#include "StdAfx.h"
#include "VehicleWheelsDynData.h"

void VehicleWheelsDynData::SetToRestState()
{
	throw gcnew NotImplementedException();
}

void VehicleWheelsDynData::SetTireForceShaderFunction(IVehicleComputeTireForceInput^ input, IVehicleComputeTireForceOutput^ output)
{
	throw gcnew NotImplementedException();
}