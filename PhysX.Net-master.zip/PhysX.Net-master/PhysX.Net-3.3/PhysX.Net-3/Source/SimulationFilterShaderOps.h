#pragma once

#include "ExtensionsEnum.h"

namespace PhysX
{
	public value class SimulationFilterShaderOps
	{
	public:
		property FilterOp Op0;
		property FilterOp Op1;
		property FilterOp Op2;
	};
}