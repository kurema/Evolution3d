#pragma once


namespace PhysX
{
	public ref class FixedSizeLookupTable
	{
		/*private:
			PxFixedSizeLookupTable* _table;

		public:
			void AddPair(float x, float y);
			float GetYValue(float x);

			property int NumberOfPairs
			{
				int get();
			}*/
	};
};