#include "StdAfx.h"
#include "VisualDebuggerExt.h"
#include "ConnectionManager.h"
#include "VisualDebuggerEnum.h"

using namespace PhysX;
using namespace PhysX::VisualDebugger;

VisualDebuggerExt::VisualDebuggerExt()
{
	
}