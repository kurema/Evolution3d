#include "StdAfx.h"
#include "DebugPoint.h"

DebugPoint::DebugPoint(Vector3 point, int color)
{
	Point = point;
	Color = color;
}