#include "StdAfx.h"
#include "InputStream.h"

InputStream::InputStream()
{

}