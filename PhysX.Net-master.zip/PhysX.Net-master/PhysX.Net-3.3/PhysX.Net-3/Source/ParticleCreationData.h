#pragma once


namespace PhysX
{
	/// <summary>
	/// Descriptor-like user-side class describing buffers for particle creation.
	/// </summary>
	public ref class ParticleCreationData
	{
		internal:
			static PxParticleCreationData ToUnmanaged(ParticleCreationData^ data);

		public:
			property int NumberOfParticles;

			property array<int>^ IndexBuffer;
			property array<Vector3>^ PositionBuffer;
			property array<Vector3>^ VelocityBuffer;
			property array<Vector3>^ RestOffsetBuffer;
			property array<int>^ FlagBuffer;
	};
};