#include "StdAfx.h"
#include "VehicleConcurrentUpdateData.h"
