#pragma once

namespace PhysX
{
	public ref class ConstraintDesc
	{
		public:
			ConstraintDesc();
	};
};