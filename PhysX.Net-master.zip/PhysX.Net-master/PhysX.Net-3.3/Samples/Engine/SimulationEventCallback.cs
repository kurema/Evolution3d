﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhysX.Samples.Engine
{
	public class SimulationEventCallback : PhysX.SimulationEventCallback
	{
		
	}
}