﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhysX.Samples.VehicleSample
{
	public enum TyreType
	{
		Wets = 0,
		Slicks,
		Ice,
		Mud
	}
}