﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhysX.Samples.VehicleSample
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			new VehicleSample();
		}
	}
}