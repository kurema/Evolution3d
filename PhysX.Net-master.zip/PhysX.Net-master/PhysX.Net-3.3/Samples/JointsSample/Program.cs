﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhysX.Samples.JointsSample
{
	public class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			new JointsSample();
		}
	}
}