﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhysX.Samples.RigidBodiesSample
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			new RigidBodiesSample();
		}
	}
}
