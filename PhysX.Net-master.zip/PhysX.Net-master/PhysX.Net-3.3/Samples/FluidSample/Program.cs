﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhysX.Samples.FluidSample
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			new FluidSample();
		}
	}
}